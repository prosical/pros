package com.spring.myapp.reply.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.myapp.commons.paging.Criteria;
import com.spring.myapp.reply.model.ReplyVO;
import com.spring.myapp.reply.repository.IReplyDAO;

@Service
public class ReplyService implements IReplyService {
	
	@Autowired
	private IReplyDAO dao;

	
	@Override
	public List<ReplyVO> list(int boardNo) throws Exception {
		return dao.list(boardNo);
	}

	@Override
	public void insert(ReplyVO reply) throws Exception {
		dao.insert(reply);
	}

	@Override
	public void update(ReplyVO reply) throws Exception {
		dao.update(reply);
	}

	@Override
	public void delete(int replyNo) throws Exception {
		dao.delete(replyNo);
	}

	@Override
	public List<ReplyVO> listPaging(Criteria cri, int boardNo) throws Exception {
		return dao.listPaging(cri, boardNo);
	}

	@Override
	public int countReplies(int boardNo) throws Exception {
		return dao.countReplies(boardNo);
	}

}
