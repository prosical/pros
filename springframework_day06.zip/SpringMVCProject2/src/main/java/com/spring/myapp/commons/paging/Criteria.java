package com.spring.myapp.commons.paging;

public class Criteria {
	
	//사용자가 요청한 페이지번호
	private int Page;
	//한 페이지 당 들어갈 게시물 수
	private int countPerPage;
	
	public Criteria() {
		this.Page = 1;
		this.countPerPage = 10;
	}

	public int getPage() {
		return Page;
	}

	public void setPage(int page) {
		if(page <= 0) {
			this.Page = 1;
			return;
		}
		this.Page = page;
	}

	public int getCountPerPage() {
		return countPerPage;
	}

	public void setCountPerPage(int countPerPage) {
		if(countPerPage <=0 || countPerPage >100) {
			this.countPerPage = 10;
			return;
		}
		this.countPerPage = countPerPage;
	}
	
	//sql limit절의 인덱스 시작 번호 구하는 메서드
	public int getPageStart() {
		return (this.Page - 1) * countPerPage;
	}

	@Override
	public String toString() {
		return "Criteria [page=" + Page + ", countPerPage=" + countPerPage + "]";
	}
	
}
