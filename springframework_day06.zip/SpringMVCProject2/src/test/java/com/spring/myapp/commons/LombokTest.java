package com.spring.myapp.commons;

import lombok.Data;

@Data
public class LombokTest {

	private String name;
	private String address;
	private String phoneNumber;
	private int age;

	
}
