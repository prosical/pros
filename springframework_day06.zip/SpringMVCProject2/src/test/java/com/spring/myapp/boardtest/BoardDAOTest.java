package com.spring.myapp.boardtest;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.spring.myapp.board.model.BoardVO;
import com.spring.myapp.board.repository.IBoardDAO;
import com.spring.myapp.commons.paging.Criteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:/spring/mvc-config.xml"})
public class BoardDAOTest {

	private static final Logger logger = LoggerFactory.getLogger(BoardDAOTest.class);

	@Inject
	private IBoardDAO boardDAO;

	//게시물 등록 테스트
	/*@Test
	public void insertTest() throws Exception {
		for (int i = 1; i<=3000; i++) {
			BoardVO vo = new BoardVO();
			vo.setTitle(i +" 번째 테스트 게시물");
			vo.setContent(i+" 번째 게시물 내용입니다.");
			vo.setWriter("작성자"+i);
			boardDAO.insert(vo);
		}
	}*/

	//게시물 정보 조회 테스트
	/*@Test
	public void selectTest() throws Exception {
		logger.info(boardDAO.getArticle(55).toString());
	}*/

	//게시물 수정 테스트
	/*@Test
	public void updateTest() throws Exception{
		BoardVO vo = new BoardVO();
		vo.setBoardNo(5);
		vo.setTitle("sssssss");
		vo.setContent("ddddddddd");
		boardDAO.update(vo);
	}*/

	//게시글 삭제 테스트
	/*@Test
	public void deleteTest() throws Exception {
		boardDAO.delete(9);
	}*/

	//모든 게시물 조회
	/*@Test
	public void selectAllTest() throws Exception {
		List<BoardVO> articles = boardDAO.getAllArticles();
		for(BoardVO article : articles) {
			logger.info(article.toString());
		}
	}*/

	//페이지 테스트
	@Test
	public void testlistPaging() throws Exception {
		Criteria c = new Criteria();
		c.setPage(5);
		c.setCountPerPage(15);
		for(BoardVO article:boardDAO.listPaging(c)) {
			logger.info(article.toString());
		}
	}

}
